package dao;

import org.hibernate.*;

import pojos1.*;

import static utils.HibernateUtils.*;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

public class HibernateDao2 {
	// CREATE
	public Integer registerUser(User u) {
		Integer id = null;
		// get a NEW session object from SF
		Session hs = getSf().openSession();
		// begin tx
		Transaction tx = hs.beginTransaction();
		try {
			id = (Integer) hs.save(u);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			hs.close();
		}
		return id;
	}

	// get user details by ID
	public User registerUser(int userId) {
		User u = null;
		// get a NEW session object from SF
		Session hs = getSf().openSession();
		// begin tx
		Transaction tx = hs.beginTransaction();
		try {
			u = hs.get(User.class, userId);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			hs.close();
		}
		return u;
	}

	// get user details by ID
	public List<User> getUsersByCriteria() {
		List<User> l1 = null;
		// get a NEW session object from SF
		Session hs = getSf().openSession();
		// begin tx
		Transaction tx = hs.beginTransaction();
		try {
			CriteriaBuilder builder = hs.getCriteriaBuilder();
			CriteriaQuery<User> query=builder.createQuery(User.class);
			query.from(User.class);
			l1 = hs.createQuery(query).getResultList();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		} finally {
			hs.close();
		}
		return l1;
	}

}
