package dao;

import static utils.HibernateUtils.getSf;
import org.hibernate.*;
import pojos1.Author;
import pojos1.Book;


public class MappingDao1 {
	public Integer saveInfo(Author a) {
		Integer id=null;
		Session hs = getSf().getCurrentSession();
		// begin tx
		Transaction tx = hs.beginTransaction();
		try {
			for(Book b : a.getBooks())
				hs.save(b);
			id=(Integer)hs.save(a);
			tx.commit();
		} catch (HibernateException e) {

			if (tx != null)
				tx.rollback();
			throw e;
		}

		return id;
	}
}
