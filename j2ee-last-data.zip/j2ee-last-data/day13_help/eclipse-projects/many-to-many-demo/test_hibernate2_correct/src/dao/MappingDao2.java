package dao;

import static utils.HibernateUtils.getSf;
import org.hibernate.*;
import pojos2.*;


public class MappingDao2 {
	public Integer saveInfo(Author a) {
		Integer id = null;
		Session hs = getSf().getCurrentSession();
		// begin tx
		Transaction tx = hs.beginTransaction();
		try {
			id = (Integer) hs.save(a);
			tx.commit();
		} catch (HibernateException e) {

			if (tx != null)
				tx.rollback();
			throw e;
		}

		return id;
	}
}
