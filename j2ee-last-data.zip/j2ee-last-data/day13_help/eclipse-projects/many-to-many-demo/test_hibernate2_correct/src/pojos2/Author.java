package pojos2;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="auth1")
public class Author {
	private Integer authId;
	private String name;
	private List<Book> books=new ArrayList<>();
	public Author() {
		System.out.println("in auth constr");
	}
	
	public Author(String name) {
		super();
		this.name = name;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="auth_id")
	public Integer getAuthId() {
		return authId;
	}
	public void setAuthId(Integer authId) {
		this.authId = authId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@OneToMany(cascade=CascadeType.ALL,mappedBy="auth")
	public List<Book> getBooks() {
		return books;
	}
	public void setBooks(List<Book> books) {
		this.books = books;
	}
	public void addBooks(List<Book> bks)
	{
		for(Book b : bks)
		{
			books.add(b);
			b.setAuth(this);
		}
	}
	@Override
	public String toString() {
		return "Author [authId=" + authId + ", name=" + name + "]";
	}
	

}
