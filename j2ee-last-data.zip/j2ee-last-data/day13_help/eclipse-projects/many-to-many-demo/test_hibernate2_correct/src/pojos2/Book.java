package pojos2;

import javax.persistence.*;

@Entity
@Table(name = "bk1")
public class Book {
	private Integer id;
	private String title;
	private Author auth;

	public Book() {
		System.out.println("bk constr");
	}
	
	public Book(String title) {
		super();
		this.title = title;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	@Column(length=20)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	@ManyToOne
	@JoinColumn(name="au_id")
	public Author getAuth() {
		return auth;
	}
	public void setAuth(Author auth) {
		this.auth = auth;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", title=" + title + "]";
	}

}
