package pojos1;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name="dmc_hib_users")
public class User {
	
	private Integer userId;
	private String email, password;
	private double amount;
	private Date regDate;

	public User() {
		System.out.println("in user's def constr");
	}

	public User(int userId, String email, String password, double amount, Date regDate) {
		super();
		this.userId = userId;
		this.email = email;
		this.password = password;
		this.amount = amount;
		this.regDate = regDate;
	}
	

	public User(String email, String password, double amount, Date regDate) {
		super();
		this.email = email;
		this.password = password;
		this.amount = amount;
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "User userId=" + userId + ", email=" + email + ", amount=" + amount + ", regDate=" + regDate;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="user_id")
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		System.out.println(1);
		this.userId = userId;
	}
	@Column(length=20,unique=true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		System.out.println(2);
		this.email = email;
	}
	@Column(length=10)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println(3);
		this.password = password;
	}
	@Column(name="amt",columnDefinition="double(6,1)")
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		System.out.println(4);
		this.amount = amount;
	}
	@Column(name="reg_dt")
	@Temporal(TemporalType.DATE)
	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		System.out.println(5);
		this.regDate = regDate;
	}
}
