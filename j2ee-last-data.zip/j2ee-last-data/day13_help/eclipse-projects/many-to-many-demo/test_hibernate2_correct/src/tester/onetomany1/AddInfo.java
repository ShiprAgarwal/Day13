package tester.onetomany1;

import static utils.HibernateUtils.*;


import java.util.Arrays;

import java.util.Scanner;

import org.hibernate.SessionFactory;


import dao.MappingDao1;
import pojos1.*;



public class AddInfo {

	public static void main(String[] args) {
		SessionFactory sf = null;

		try (Scanner sc = new Scanner(System.in)) {
			sf = getSf();
			System.out.println("Enter author name");
			Author a1 = new Author(sc.next());
			System.out.println("Enter Book 1 title");
			Book b1 = new Book(sc.next());
			System.out.println("Enter Book 2 title");
			Book b2 = new Book(sc.next());
			a1.addBooks(Arrays.asList(b1, b2));
			System.out.println(new MappingDao1().saveInfo(a1));

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sf.close();
		}
	}

}
