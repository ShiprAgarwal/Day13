package tester;

import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.HibernateDao;
import pojos1.User;

public class GetUserDetails {

	public static void main(String[] args) {
		SessionFactory sf = null;

		try (Scanner sc = new Scanner(System.in)) {
			sf = getSf();
			System.out.println("Enter user id");
			System.out.println("User Details " + new HibernateDao().getUserDetails(sc.nextInt()));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sf.close();
		}
	}

}
