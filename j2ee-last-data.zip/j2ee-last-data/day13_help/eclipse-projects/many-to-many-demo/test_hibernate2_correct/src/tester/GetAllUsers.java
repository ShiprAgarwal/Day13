package tester;

import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.HibernateDao;
import pojos1.User;

public class GetAllUsers {

	public static void main(String[] args) {
		SessionFactory sf = null;

		try {
			sf = getSf();

			System.out.println("All User Details ");
			List<User> list = new HibernateDao().getAllUserDetails();
			for(User u : list)
				System.out.println(u);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sf.close();
		}
	}

}
