package tester;

import static utils.HibernateUtils.*;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.HibernateDao;
import pojos1.User;

public class RegisterUser {

	public static void main(String[] args) {
		SessionFactory sf=null;
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		try(Scanner sc=new Scanner(System.in)) {
			sf = getSf();
			System.out.println("Enter user details em pass amt date");
			//create TRANSIENT POJO
			User u1=new User(sc.next(), sc.next(), 
					sc.nextDouble(), sdf.parse(sc.next()));
			System.out.println("User ID "+
					new HibernateDao().registerUser(u1));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sf.close();
		}
	}

}
