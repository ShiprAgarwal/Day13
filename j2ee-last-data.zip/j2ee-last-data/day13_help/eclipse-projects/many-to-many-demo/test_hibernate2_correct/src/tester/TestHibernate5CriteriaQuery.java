package tester;

import static utils.HibernateUtils.getSf;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.hibernate.SessionFactory;

import dao.HibernateDao2;
import pojos1.User;

public class TestHibernate5CriteriaQuery {

	public static void main(String[] args) {
		SessionFactory sf=null;
	
		try{
			sf = getSf();
			System.out.println("Users \n"+
					new HibernateDao2().getUsersByCriteria());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sf.close();
		}

	}

}
