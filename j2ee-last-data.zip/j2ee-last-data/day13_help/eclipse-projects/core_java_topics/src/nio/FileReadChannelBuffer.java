package nio;

import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.Paths;
import java.util.Scanner;

public class FileReadChannelBuffer {
	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Enter file name");
			FileChannel fc = FileChannel.open(Paths.get(sc.nextLine()));
			ByteBuffer bb = ByteBuffer.allocate(100);

			while (fc.read(bb) != -1) {
				System.out.println("looping");
				bb.rewind();
				String str= Charset.forName("UTF-8").decode(bb).toString();
				System.out.println(str);
				bb.flip();

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
