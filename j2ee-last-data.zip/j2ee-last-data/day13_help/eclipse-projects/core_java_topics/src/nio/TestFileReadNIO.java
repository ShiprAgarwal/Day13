package nio;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class TestFileReadNIO {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			Files.lines(Paths.get(sc.nextLine())).filter(l->l.length()<40).forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
