About eclipse projects

1. spring_mvc_hibernate_vendors
Complete case study with spring-mvc-hibernate + one-to-many association between entities + Presentation logic vaidations

2. rest server test with postman