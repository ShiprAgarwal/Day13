package com.app.pojos;

public enum AcType {
	SAVING,CURRENT,FD,LOAN,DMAT
}
