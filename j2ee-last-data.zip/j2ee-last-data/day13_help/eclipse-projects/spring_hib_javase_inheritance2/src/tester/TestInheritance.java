package tester;

import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.app.dao.EmpDao;
import com.app.dao.EmpDaoImpl;
import com.app.pojos.FullTimeEmployee;
import com.app.pojos.PartTimeEmployee;

public class TestInheritance {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in);
				ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("main-config.xml")) {
			System.out.println("sc strted");
			FullTimeEmployee e1 = new FullTimeEmployee();
			e1.setName("Rama");
			e1.setSalary(10000);
			System.out.println(e1);

			PartTimeEmployee e2 = new PartTimeEmployee();
			e2.setName("Kiran");
			e2.setHourlyRate(60);
			System.out.println(e2);
			EmpDao dao=ctx.getBean(EmpDao.class);
			dao.saveEmp(e1);
			dao.saveEmp(e2);
			dao.listEmps().forEach(System.out::println);
			

		}

	}

}
