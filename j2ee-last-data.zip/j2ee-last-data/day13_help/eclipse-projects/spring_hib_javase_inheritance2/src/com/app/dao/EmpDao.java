package com.app.dao;

import java.util.List;

import com.app.pojos.Employee;

public interface EmpDao {
	public String saveEmp(Employee e);
	public List<Employee> listEmps();
}
