package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Employee;

@Repository
@Transactional
public class EmpDaoImpl implements EmpDao {
	@Autowired
	private SessionFactory sf;

	@Override
	public String saveEmp(Employee e) {
		sf.getCurrentSession().save(e);
		return "Emp saved with id "+e.getId();
	}

	@Override
	public List<Employee> listEmps() {
		String jpql="select e from Employee e";
		return sf.getCurrentSession().createQuery(jpql, Employee.class).getResultList();
	}

}
