package tester;

import static utils.HibernateUtils.*;


import java.util.Arrays;
import java.util.Scanner;

import dao.CourseDao;
import pojos.Address;
import pojos.Course;
import pojos.PhoneNo;
import pojos.Student;
import pojos.Vehicle;

public class SaveCourseNStudentDetails {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			getSf();
			System.out.println("Enter course name");
			Course c1 = new Course(sc.next());
			for (int i = 0; i < 3; i++) {
				System.out.println("Enter student email");
				Student s=new Student(sc.next());
				System.out.println("Enter your city");
				s.addAddress(new Address(sc.next()));
				System.out.println("Enter landline n cell phone numbers");
				s.setPhoneNumbers(Arrays.asList(new PhoneNo(sc.next()),new PhoneNo(sc.next())));
				System.out.println("Enter your vehicle reg no");
				s.setVehicle(new Vehicle(sc.next()));
				sc.nextLine();
				System.out.println("Enter your hobbies , quit to stop");
				while(true)
				{
					String hobby=sc.next();
					if(hobby.equals("quit"))
						break;
					s.getHobbies().add(sc.next());
				}
				//add student dtls to course				
				c1.addStudent(s);
			}
			// invoke dao's method
			System.out.println(new CourseDao().
					saveCourseInfo(c1));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getSf().close();
		}

	}

}
