package dao;

import org.hibernate.*;
import pojos.*;
import static utils.HibernateUtils.*;

public class CourseDao {
	public String saveCourseInfo(Course c) {
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			hs.persist(c);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return "Course added with ID=" + c.getCourseId();
	}

	public Course getCourseInfo(String name) {
		Course c = null;
		String jpql = "select c from Course c join fetch c.students where c.name= :nm";
		Session hs = getSf().getCurrentSession();
		Transaction tx = hs.beginTransaction();
		try {
			c = hs.createQuery(jpql, Course.class).
					setParameter("nm", name).getSingleResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return c;
	}

}
