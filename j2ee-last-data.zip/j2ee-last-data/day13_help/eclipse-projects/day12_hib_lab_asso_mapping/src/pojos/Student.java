package pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "dac_students")
public class Student {
	private Integer studentId;
	private String email;
	// one--to--many bi dir
	private Course myCourse;
	// one to one bi dir (inverse side)
	private Address adr;
	// embedded one -to -many
	private List<PhoneNo> phoneNumbers = new ArrayList<>();
	// embedded one -to-one
	private Vehicle vehicle;
	// embedded basic type one --many
	private List<String> hobbies = new ArrayList<>();

	public Student() {
		System.out.println("in stud cnstr");
	}

	public Student(String email) {
		super();
		this.email = email;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "student_id")
	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	@Column(length = 10, unique = true)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@ManyToOne // mandatory : o.w MappingExc
	@JoinColumn(name = "cour_id") // optional
	public Course getMyCourse() {
		return myCourse;
	}

	public void setMyCourse(Course myCourse) {
		this.myCourse = myCourse;
	}
	@OneToOne(cascade=CascadeType.ALL,mappedBy="stud")
	public Address getAdr() {
		return adr;
	}

	public void setAdr(Address adr) {
		this.adr = adr;
	}
	//convenience method to add address details in bi-dir manner
	public void addAddress(Address a)
	{
		setAdr(a);
		a.setStud(this);//rev asso
	}
	
	@ElementCollection //mandatory
	//optional
	@CollectionTable(name="stud_phones",joinColumns=@JoinColumn(name="stud_id"))
	public List<PhoneNo> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(List<PhoneNo> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	@Embedded //optional
	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}
	@ElementCollection //mandatory
	//optional
	@CollectionTable(name="stud_hobbies",joinColumns=@JoinColumn(name="stud_id"))
	public List<String> getHobbies() {
		return hobbies;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", email=" + email + "]";
	}

}
