package pojos;
import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@Table(name="dac_courses")
public class Course {
	private Integer courseId;
	private String name;
	//asso property
	private List<Student> students=new ArrayList<>();
	
	public Course() {
		System.out.println("in course cnstr");
	}
	public Course(String name) {
		super();
		this.name = name;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="c_id")
	public Integer getCourseId() {
		return courseId;
	}
	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}
	@Column(length=10,unique=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@OneToMany(cascade=CascadeType.ALL,mappedBy="myCourse")
	public List<Student> getStudents() {
		return students;
	}
	public void setStudents(List<Student> students) {
		this.students = students;
	}
	//covenience method for establishing bi-dir asso
	public void addStudent(Student s)
	{
		students.add(s);
		//add rev asso
		s.setMyCourse(this);
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", name=" + name + "]";
	}
	

}
