package pojos;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/*embedded component 
* no independent life cycle / prim key. Dependent upon owning entity
* */
@Embeddable
public class Vehicle {

	private String regNo;

	public Vehicle() {
		System.out.println("vehicle constr");
	}

	public Vehicle(String regNo) {
		super();
		this.regNo = regNo;
	}
	@Column(length=10,name="reg_no")
	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	@Override
	public String toString() {
		return "Vehicle reg no " + regNo;
	}

}
