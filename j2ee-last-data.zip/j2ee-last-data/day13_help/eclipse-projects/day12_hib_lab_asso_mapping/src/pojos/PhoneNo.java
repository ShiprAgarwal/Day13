package pojos;

import javax.persistence.*;


/*embedded component 
* no independent life cycle / prim key. Dependent upon owning entity
* */

@Embeddable
public class PhoneNo {
	private String phoneNo;

	public PhoneNo() {
		System.out.println("phone def constr");
	}

	public PhoneNo(String phoneNo) {
		super();
		this.phoneNo = phoneNo;
	}
	@Column(length=10,name="ph_no")
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "PhoneNo [phoneNo=" + phoneNo + "]";
	}
	
	

}
