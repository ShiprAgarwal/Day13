package pojos;
import javax.persistence.*;

@Entity
@Table(name="dac_adr")
public class Address {
	private Integer id;
	private String city;
	//one-to-one bi dir owning side (FK column)
	private Student stud;

	public Address() {
		System.out.println("in adr cnstr");
	}

	public Address(String city) {
		super();
		this.city = city;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "adr_id")
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(length=10)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	@OneToOne
	@JoinColumn(name="stud_id")
	public Student getStud() {
		return stud;
	}

	public void setStud(Student stud) {
		this.stud = stud;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", city=" + city + "]";
	}
	
	
}
