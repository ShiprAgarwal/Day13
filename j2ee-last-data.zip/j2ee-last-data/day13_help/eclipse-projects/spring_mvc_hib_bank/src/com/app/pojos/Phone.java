package com.app.pojos;

import javax.persistence.*;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Embeddable
public class Phone {
	@NotEmpty
	private String type;
	@Range(min=1,message="Invalid Number")
	private long number;
	public Phone() {
		// TODO Auto-generated constructor stub
	}
	public Phone(String type, long number) {
		super();
		this.type = type;
		this.number = number;
	}
	@Column(length=15)
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Column(name="phone_no")
	public long getNumber() {
		return number;
	}
	public void setNumber(long number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "Phone [type=" + type + ", number=" + number + "]";
	}
	

}
