package com.app.controllers;



import javax.persistence.NoResultException;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.app.pojos.BankAccount;
import com.app.pojos.BankUser;
import com.app.pojos.UserAddress;
import com.app.service.BankService;


@Controller
@RequestMapping("/bank")
public class BankController {
	@Autowired
	private BankService service;

	@GetMapping(value = "/login")
	public String showLoginForm(BankUser user) {
		System.out.println("in show login form");
		return "login";
	}

	@PostMapping(value = "/login")
	public String ProcessLoginForm(@Valid BankUser user, BindingResult res, HttpSession hs, RedirectAttributes attr,
			Model map) {
		System.out.println("in process login form " + user);
		if (res.hasErrors()) {
			System.out.println("p.l errs");
			return "login";
		}
		// invoke service layer method
		try {
			BankUser user1 = service.validateCustomer(user.getName(), user.getPassword());
			hs.setAttribute("bank_user", user1);
			attr.addFlashAttribute("mesg", "Successful Login");
		} catch (NoResultException e) {
			System.out.println("invalid login");
			map.addAttribute("mesg", "Invalid Login , pls retry");
			return "login";
		} catch (Exception e) {
			map.addAttribute("mesg", "Server internal error " + e.getMessage());
			return "login";
		}
		return "redirect:/bank/summary";
	}

	@PostMapping(value = "/register")
	public String ProcessRegForm(@Valid BankUser user, BindingResult res, Model map, HttpSession hs, UserAddress adr) {
		System.out.println("in process reg form " + user);
		if (res.hasErrors()) {
			System.out.println("p.l errs");
			return "login";
		}
		map.addAttribute("mesg", "Proceed to register your address");
		hs.setAttribute("bank_user", user);
		return "reg_adr";
	}

	@PostMapping(value = "/reg_adr")
	public String processRegAdrForm(@Valid UserAddress adr, BindingResult res, HttpSession hs, RedirectAttributes attr,
			Model map) {
		System.out.println("in process reg adr form " + adr);

		if (res.hasErrors()) {
			System.out.println("p.l errs");
			return "login";
		}
		BankUser user = (BankUser) hs.getAttribute("bank_user");
		user.setAdr(adr);

		attr.addFlashAttribute("mesg", service.registerUser(user));
		hs.invalidate();
		return "redirect:/bank/login";
	}

	@GetMapping(value = "/summary")
	public String showSummary(HttpSession hs, BankAccount acct) {
		System.out.println("in show summary ");
		BankUser user = (BankUser) hs.getAttribute("bank_user");
		user.setAccts(service.getAccounts(user.getUserId()));
		return "summary";
	}

	@GetMapping(value = "/{path}")
	public String globalMapping(@PathVariable String path) {
		System.out.println("in global mapping " + path);
		return path;
	}

	@PostMapping(value = "/close")
	public String closeAccount(@Valid BankAccount acct, BindingResult res, RedirectAttributes attr) {
		System.out.println("in close acct " + acct);
	
		if (res.hasFieldErrors("acctId")) {
			attr.addFlashAttribute("mesg", "Acct Id must be chosen");
		} else
			attr.addFlashAttribute("mesg", service.closeAccount(acct));
		return "redirect:/bank/summary";
	}

	@PostMapping(value = "/transactions")
	public String performTransactions(@Valid BankAccount acct, BindingResult res, @RequestParam String btn,
			RedirectAttributes attr) {
		System.out.println("in perform txs " + acct + " " + btn + " " +res);
		if (acct.getAcctId() == null || res.hasFieldErrors("amount")) {
			attr.addFlashAttribute("mesg", "Acct Id & amount must be filled");
		} else {
			double amount = acct.getAmount();
			if (btn.equals("Withdraw"))
				amount = -amount;
			attr.addFlashAttribute("mesg", service.updateAccount(acct.getAcctId(), amount));
		}
		return "redirect:/bank/summary";
	}

	@GetMapping(value = "/logout")
	public String logOut(HttpSession hs, Model map) {
		System.out.println("in logout ");
		map.addAttribute("bank_user", hs.getAttribute("bank_user"));
		map.addAttribute("mesg", "U have successfully logged out , will be taken to login page shortly");
		hs.invalidate();
		return "logout";
	}

	@PostMapping(value = "/create")
	public String showCreateAcForm(BankAccount acct) {
		System.out.println("in show a/c create  form ");
		return "create";
	}

	@PostMapping(value = "/create_ac")
	public String processCreateAc(@Valid BankAccount acct, BindingResult res, RedirectAttributes attr, HttpSession hs) {
		System.out.println("in create a/c " + acct);
		System.out.println(res);
		if (res.hasFieldErrors("type") || res.hasFieldErrors("balance")) {
			return "create";
		} else {
			System.out.println("no pl errs");
			attr.addFlashAttribute("mesg", service.createAccount((BankUser) hs.getAttribute("bank_user"), acct));
		}
		return "redirect:/bank/summary";
	}

}
