package com.app.pojos;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name="dac_bank_accts")
public class BankAccount {
	
	private Integer acctId;
	@NotEmpty
	private String type;
	@Range(min=1000,message="Insufficient Opening Balance")
	private double balance;
	@Range(min=1,message="Choose Correct Amount")
	private double amount;
	private BankUser user;
	

	public BankAccount() {
		System.out.println("in bank acct cnstr");
	}

	public BankAccount(String type, double balance) {
		super();
		this.type = type;
		this.balance = balance;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="acct_id")
	public Integer getAcctId() {
		return acctId;
	}

	public void setAcctId(Integer acctId) {
		this.acctId = acctId;
	}
	@Column(length=10)
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	@Column(columnDefinition="double(7,1)")
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	@ManyToOne
	@JoinColumn(name="usr_id")
	public BankUser getUser() {
		return user;
	}

	public void setUser(BankUser user) {
		this.user = user;
	}
	

	/*@Override
	public int hashCode() {
		System.out.println("in hc");
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acctId == null) ? 0 : acctId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("in equals");
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BankAccount other = (BankAccount) obj;
		if (acctId == null) {
			if (other.acctId != null)
				return false;
		} else if (!acctId.equals(other.acctId))
			return false;
		return true;
	}*/
	
	@Transient
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return  acctId + " " + type + " "+ balance; 
	}

}
