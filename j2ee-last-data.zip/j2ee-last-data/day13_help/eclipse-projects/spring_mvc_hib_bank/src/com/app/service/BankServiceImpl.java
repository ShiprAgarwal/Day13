package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.BankDao;
import com.app.pojos.BankAccount;
import com.app.pojos.BankUser;

@Service("bank_service")
@Transactional

public class BankServiceImpl implements BankService {
	@Autowired
	private BankDao dao;

	@Override
	public BankUser validateCustomer(String nm1, String pass) {
		
		BankUser user=dao.validateCustomer(nm1, pass);
	//	user.setAccts(dao.getAccounts(user.getUserId()));
		return user;
		
	}

	@Override
	public List<BankAccount> getAccounts(int userId) {
		// TODO Auto-generated method stub
		return dao.getAccounts(userId);
	}

	@Override
	public String updateAccount(int acctId, double amt) {
		// TODO Auto-generated method stub
		return dao.updateAccount(acctId, amt);
	}

	@Override
	public String createAccount(BankUser u1, BankAccount a) {
		// TODO Auto-generated method stub
		return dao.createAccount(u1, a);
	}

	@Override
	public String closeAccount(BankAccount a) {
		// TODO Auto-generated method stub
		return dao.closeAccount(a);
	}

	@Override
	public String registerUser(BankUser u) {
		// TODO Auto-generated method stub
		return dao.registerUser(u);
	}

}
