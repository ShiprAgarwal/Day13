package com.app.pojos;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "dac_bank_user")
public class BankUser {
	private Integer userId;
//	@NotEmpty(message = "Name Required")
	@Length(min = 3, max = 20, message = "Invalid name")
	private String name;
	@Pattern(regexp = "((?=.*\\d)(?=.*[a-z])(?=.*[#@$*]).{5,20})", message = "Blank or Invalid Password")
	private String password;
	// one -- many between entities
	private List<BankAccount> accts = new ArrayList<>();
	// one --one between entities
	private UserAddress adr;

	public BankUser() {
		System.out.println("in bank user constr");
	}

	public BankUser(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(length = 20)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(length = 10)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "user")
	public List<BankAccount> getAccts() {
		return accts;
	}

	public void setAccts(List<BankAccount> accts) {
		this.accts = accts;
	}

	// convenience method
	public void addAccount(BankAccount a) {
		getAccts().add(a);
		a.setUser(this);
	}

	// convenience method not needed
	/*
	 * public void removeAccount(BankAccount a){
	 * System.out.println("A/C removed "+getAccts().remove(a)); a.setUser(null);
	 * }
	 */
	@OneToOne(fetch = FetchType.LAZY,cascade=CascadeType.ALL) // (mappedBy = "user", cascade =
										// CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name = "adr_id")
	public UserAddress getAdr() {
		return adr;
	}

	public void setAdr(UserAddress adr) {
		this.adr = adr;
	}

	@Override
	public String toString() {
		return "BankUser [userId=" + userId + ", name=" + name + ", password=" + password + "]";
	}

}
