package com.app.service;

import java.util.List;

import com.app.pojos.BankAccount;
import com.app.pojos.BankUser;

public interface BankService {

	// validation of bank user
	BankUser validateCustomer(String nm1, String pass);

	// get accounts for a logged in user
	List<BankAccount> getAccounts(int userId);

	// update bank a/c
	String updateAccount(int acctId, double amt);

	// create bank a/c
	String createAccount(BankUser u1, BankAccount a);

	// close bank a/c
	String closeAccount(BankAccount a);

	// register bank user
	String registerUser(BankUser u);

}