package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "dac_user_adr")
public class UserAddress {
	private Integer id;
	@NotEmpty
	private String city;
	@NotEmpty
	private String state;
	@NotEmpty
	private String country;
	private List<Phone> phones = new ArrayList<>();
	private BankUser user;

	public UserAddress() {
		// TODO Auto-generated constructor stub
	}

	public UserAddress(String city, String state, String country) {
		super();
		this.city = city;
		this.state = state;
		this.country = country;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(length = 20)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(length = 20)
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(length = 20)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@ElementCollection
	@CollectionTable(name = "user_phones", 
	joinColumns = { @JoinColumn(name = "adr_id") })
	public List<Phone> getPhones() {
		return phones;
	}

	public void setPhones(List<Phone> phones) {
		this.phones = phones;
	}

	@OneToOne(mappedBy = "adr")
	// @JoinColumn(name="user_id")
	public BankUser getUser() {
		return user;
	}

	public void setUser(BankUser user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "UserAddress [city=" + city + ", state=" + state + ", country=" + country + ", phones=" + phones;
	}

}
