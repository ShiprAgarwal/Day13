package com.app.dao;

import com.app.pojos.*;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BankDaoImpl implements BankDao {
	// Dependency -- SF
	@Autowired
	private SessionFactory sf;

	// validation of bank user
	@Override
	public BankUser validateCustomer(String nm1, String pass) {
		System.out.println("dao : validate customer");
		String hql = "select u from BankUser u where u.name = :nm and u.password = :pa";
		Session hs = sf.getCurrentSession();
		BankUser user = hs.createQuery(hql, BankUser.class).setParameter("nm", nm1).setParameter("pa", pass)
				.getSingleResult();

		System.out.println("dao ret validate");
		return user;
	}

	// get accounts for a logged in user
	@Override
	public List<BankAccount> getAccounts(int userId) {
		System.out.println("dao : get accts");

		Session hs = sf.getCurrentSession();
		
		  String hql =
		  "select b from BankUser b left outer join fetch b.accts where b.userId = :id";
		  List<BankAccount> l1 = hs.createQuery(hql,
		  BankUser.class).setParameter("id", userId).getSingleResult()
		  .getAccts();
		 
		return l1;
	}

	// update bank a/c
	@Override
	public String updateAccount(int acctId, double amt) {
		String sts = "A/C updation failed";
		System.out.println("dao : update");
		Session hs = sf.getCurrentSession();
		String hql = "update BankAccount a set a.balance = a.balance + :amt where a.acctId = :id";
		int count = hs.createQuery(hql).setParameter("amt", amt).setParameter("id", acctId).executeUpdate();
		if (count == 1)
			sts = "A/C Updated successfully";
		return sts;

	}

	// create bank a/c
	@Override
	public String createAccount(BankUser u1, BankAccount a) {
		System.out.println("dao : create a/c");
		Session hs = sf.getCurrentSession();

		// re attach Bank User with hib session

		hs.update(u1);
		u1.addAccount(a);

		return "A/C created successfully";
	}

	// close bank a/c
	@Override
	public String closeAccount(BankAccount a) {
		System.out.println("in dao close " + " " + a.getAcctId());
		Session hs = sf.getCurrentSession();

		hs.delete(a);

		return "A/C closed successfully";
	}

	// register bank user
	@Override
	public String registerUser(BankUser u) {
		Session hs = sf.getCurrentSession();

		hs.persist(u);

		return "Bank User registered with ID " + u.getUserId();
	}

}
