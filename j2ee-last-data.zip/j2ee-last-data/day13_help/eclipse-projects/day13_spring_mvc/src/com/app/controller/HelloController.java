package com.app.controller;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.pojos.Product;

@Controller //mandatory --spring bean meant for req handling purpose
public class HelloController {
	public HelloController() {
		System.out.println("in constr of "+getClass().getName());
	}

	@RequestMapping("/hello")//req handling method
	public @ResponseBody String sayHello()
	{
		System.out.println("in say hello");
		return "welcome to response body......";
	}
	@RequestMapping("/hello2")//req handling method
	public @ResponseBody List<Integer> sayHello2()
	{
		System.out.println("in say hello2");
		return Arrays.asList(10,20,30,40,50);
	}
	//URI template ---path vars
	@RequestMapping("/hello3/{pName}/{price}/{exp_date}")//req handling method for path vars
	public @ResponseBody Product sayHello3(@PathVariable String pName,@PathVariable double price,@PathVariable(name="exp_date") @DateTimeFormat(pattern="yyyy-MM-dd")Date d1)
	{
		System.out.println("in say hello3");
		return new Product(pName,price,d1);
	}
}
