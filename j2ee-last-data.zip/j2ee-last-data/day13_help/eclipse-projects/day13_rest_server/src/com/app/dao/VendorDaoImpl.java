package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import pojos.Vendor;

@Repository //mandatory
public class VendorDaoImpl implements IVendorDao {
	// dependency -- auto wiring by type --field level D.I
	@Autowired // byType
	private SessionFactory sf;
	public VendorDaoImpl() {
		System.out.println("in constr of "+getClass().getName());
	}

	@Override
	public Vendor validateUser(String em1, String pass1) {
		String jpql = "select v from Vendor v where v.email=:em and v.pwd=:pass";
		return sf.getCurrentSession().
				createQuery(jpql, Vendor.class).
				setParameter("em", em1)
				.setParameter("pass", pass1).getSingleResult();
	}

	@Override
	public List<Vendor> listAllVendors() {
		String jpql="select v from Vendor v where v.role=:rl";
		return sf.getCurrentSession().createQuery(jpql, Vendor.class).setParameter("rl", "vendor").getResultList();
	}

	@Override
	public Vendor getVendorDetails(int id) {
		// TODO Auto-generated method stub
		return sf.getCurrentSession().get(Vendor.class, id);
	}

	@Override
	public String addVendorDetails(Vendor v) {
		sf.getCurrentSession().persist(v);
		return "Vendor details added with id "+v.getId();
	}

	@Override
	public String updateVendorDetails(Vendor v) {
		sf.getCurrentSession().update(v);
		return "Vendor details updated for id "+v.getId();
	}

	@Override
	public String deleteVendorDetails(Vendor v) {
		sf.getCurrentSession().delete(v);
		return "Vendor details deleted for id "+v.getId();
	}
	
	
	

}
