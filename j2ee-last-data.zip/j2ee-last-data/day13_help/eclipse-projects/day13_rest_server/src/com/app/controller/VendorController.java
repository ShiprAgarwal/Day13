package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.service.IVendorService;

import pojos.Vendor;

@RestController
@RequestMapping("/vendors")
public class VendorController {
	@Autowired
	private IVendorService service;

	public VendorController() {
		System.out.println("in constr of " + getClass().getName());
	}

	// request handling method for listing vendor dtls
	@GetMapping
	public List<Vendor> listVendorDtls() {
		System.out.println("in list vendors");
		// directly return the list of vendors to REST clnt
		return service.listAllVendors();
	}

	@GetMapping("/{vendorId}")
	public Vendor getVendorDetailsById(@PathVariable int vendorId) {
		System.out.println("in lget vendor");

		return service.getVendorDetails(vendorId);
	}

	// req handling method to show update form pre-populated with vendor dtls
	// fetched from DB
	@GetMapping("/update")
	public String showUpdateForm(Model map, @RequestParam int vid) {
		System.out.println("in show update form " + vid);
		map.addAttribute("vendor", service.getVendorDetails(vid));
		return "/vendor/update";
	}
	//create a resource
	@PostMapping
	public String addVendor(@RequestBody Vendor v)
	{
		System.out.println("in add vendor");
		return service.addVendorDetails(v);
	}
	@PutMapping("/{vendorId}")
	public String updateDetails(@PathVariable int vendorId,@RequestBody Vendor v)
	{
		System.out.println("in update "+vendorId+" "+v);
		return service.updateVendorDetails(v);
	}
	@DeleteMapping("/{vendorId}")
	public String deleteVendor(@PathVariable int vendorId)
	{
		System.out.println("in delete "+vendorId);
		return service.deleteVendorDetails(vendorId);
	}
	
}
