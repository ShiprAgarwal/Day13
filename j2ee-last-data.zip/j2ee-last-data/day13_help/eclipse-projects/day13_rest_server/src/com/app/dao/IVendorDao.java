package com.app.dao;

import java.util.List;

import pojos.Vendor;

public interface IVendorDao {
	Vendor validateUser(String em, String pass);
	List<Vendor> listAllVendors();
	//get vendor dtls
	Vendor getVendorDetails(int id);
	//add vendor details
	String addVendorDetails(Vendor v);
	String updateVendorDetails(Vendor v);
	String deleteVendorDetails(Vendor v);
}
