package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IVendorDao;

import pojos.Vendor;

@Service // mandatory --to tell SC about B.L layer
@Transactional // to automate tx management by spring --mandatory
public class VendorServiceImpl implements IVendorService {
	@Autowired // byType
	private IVendorDao dao;

	public VendorServiceImpl() {
		System.out.println("in constr of " + getClass().getName());
	}

	@Override
	public Vendor validateUser(String em, String pass) {
		System.out.println("service : validate");
		return dao.validateUser(em, pass);
	}

	@Override
	public List<Vendor> listAllVendors() {
		// TODO Auto-generated method stub
		return dao.listAllVendors();
	}

	@Override
	public Vendor getVendorDetails(int id) {
		// TODO Auto-generated method stub
		return dao.getVendorDetails(id);
	}

	@Override
	public String addVendorDetails(Vendor v) {
		// TODO Auto-generated method stub
		return dao.addVendorDetails(v);
	}

	@Override
	public String updateVendorDetails(Vendor v) {
		return dao.updateVendorDetails(v);

	}

	@Override
	public String deleteVendorDetails(int vid) {
		return dao.deleteVendorDetails(dao.getVendorDetails(vid));

	}

}
