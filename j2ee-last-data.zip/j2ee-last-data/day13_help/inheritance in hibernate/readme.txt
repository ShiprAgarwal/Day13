JPA - Single Table Inheritance Strategy

In this strategy, all the classes in a hierarchy are mapped to a single table.

The annotation @Inheritance is used on the root entity class with strategy = InheritanceType.SINGLE_TABLE.
@DiscriminatorColumn is used on the root entity class to specify the discriminator column attributes. Discriminator is a way to differentiate rows belonging to different classes in the hierarchy.
@DiscriminatorValue is used on each persistable concrete class to specify a unique discriminator value.
@Entity and other meta-data annotations are used on the root and subclasses as usual.
@Id field should only be defined in the root class.
The root class can be abstract or a concrete class. An abstract entity differs from a concrete entity only in that it cannot be directly instantiated.
This is the default inheritance strategy. That means if we don't specify the strategy attribute of @Inheritance annotation on the the root class or don't use this annotation at all , then InheritanceType.SINGLE_TABLE strategy is assumed.
This strategy has the disadvantage of having rows with null column values for which the entity has no corresponding fields.
JPA - Joined Subclass Inheritance Strategy

In this strategy, the superclass and subclasses in a hierarchy are mapped to different individual tables.
The tables corresponding to subclasses do not contain the field from the superclass, except for the @Id fields which are mapped to the primary key(s) of each table.
The primary key column(s) of the subclass table serves as a foreign key to the primary key of the superclass table.

The annotation @Inheritance is used on the root entity class with strategy = InheritanceType.JOINED.

@DiscriminatorColumn is used on the root entity class to specify the discriminator column attributes. 

Discriminator is a way to differentiate rows belonging to different subclasses in the root table.

@DiscriminatorValue is used on each persistable subclass to specify a unique discriminator value.

@Entity and other meta-data annotations are used on the root and subclasses as usual.

@Id field should only be defined in the root class.
The root class can be abstract or a concrete class.
This strategy has the disadvantage of using one or more join queries to instantiate instances of a subclass. In deep class hierarchies, this may lead to unacceptable performance hit.