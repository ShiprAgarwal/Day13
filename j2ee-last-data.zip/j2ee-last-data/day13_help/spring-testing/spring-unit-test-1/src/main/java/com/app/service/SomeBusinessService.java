package com.app.service;

public interface SomeBusinessService {
	int calcSum(int... data);
}
