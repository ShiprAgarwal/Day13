package test_custom_annotation;

public class ApplyToMethod {
	@SomeInfo(author="xyz",version="1.3",price=350)
	public void someMethod()
	{
		
	}

}
