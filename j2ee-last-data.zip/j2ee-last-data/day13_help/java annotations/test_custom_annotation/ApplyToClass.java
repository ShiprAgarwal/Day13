package test_custom_annotation;

@SomeInfo(author="abc",price=600)
public class ApplyToClass {
	
}
