package com.app.service;


import java.util.List;

import com.app.pojos.Location;
import com.app.pojos.Student;

public interface StudentService {
	Student registerStudent(Student s);
	
}
