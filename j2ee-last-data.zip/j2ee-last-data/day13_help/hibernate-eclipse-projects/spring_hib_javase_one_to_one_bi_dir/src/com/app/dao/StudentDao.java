package com.app.dao;
import com.app.pojos.Student;

public interface StudentDao {
	Student registerStudent(Student s);
}
